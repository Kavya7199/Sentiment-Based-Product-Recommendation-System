COLS_OF_INTEREST = ['id', 'name', 'reviews_text', 'reviews_title',
                    'reviews_username', 'user_sentiment', 'reviews_rating']

OUTPUT_COLS = ['product_id', 'product_name', 'username', 'user_sentiment',
               'reviews_rating', 'reviews_title_text']

INPUT_COLS = ['id', 'name', 'reviews_username', 'user_sentiment', 'reviews_rating',
              'reviews_title', 'reviews_text']

SENTIMENTS = {'positive': 1,
              'negative': 0}

PICKLE_FILE_PATH = "model.pkl"
PICKLE_FILE_PATH_SENTIMENT = "sentiment.pkl"

NUM_PRODUCTS = 5
