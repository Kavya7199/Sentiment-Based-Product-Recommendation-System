#!/bin/bash
waitress-serve --listen=*:5000 --call "main:create_app"