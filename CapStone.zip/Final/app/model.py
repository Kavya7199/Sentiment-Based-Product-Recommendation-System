from utils import recommend_products, pickle_model


def make_prediction(user_name: str = None) -> str:
    if not user_name:
        return "Well I do hot have a User Name to make a prediction"
    try:
        products = recommend_products(username=user_name)
        if isinstance(products, list):
            html = ""
            count = 1
            for product in products:
                html = html + f"<p>{count}: {product}</p>"
                count +=1
            return html
    except Exception as error:
        return str(error)
    return "Huston, we have a problem. Kindly check the data sent"

def update_model(user_data) -> dict:
    return pickle_model(user_data=user_data)
