import os

import pandas as pd
from flask import Flask, render_template, request, url_for
from flask_bootstrap import Bootstrap5
from flask_wtf import FlaskForm
from wtforms.fields import StringField, SubmitField
from wtforms.validators import DataRequired

from constants import INPUT_COLS
from model import update_model, make_prediction

user_name = None
user_data = None


def create_app():
    class GetUserName(FlaskForm):
        user_name = StringField('User Name:', validators=[DataRequired()])
        submit = SubmitField('Submit')

    class GetUserData(FlaskForm):
        user_data_url = StringField('User Data URL:', validators=[DataRequired()])
        user_data_encoding = StringField('Data Encoding:', validators=[DataRequired()])
        submit = SubmitField('Submit')

    SECRET_KEY = os.urandom(32)
    app = Flask(__name__)
    bootstrap = Bootstrap5(app)
    app.config['SECRET_KEY'] = SECRET_KEY

    user_name = None
    user_data = None

    @app.route("/", methods=['GET', 'POST'])
    def home():
        form = GetUserName()
        if request.method == 'POST':
            if form.user_name.data and form.validate_on_submit():
                global user_name
                user_name = form.user_name.data
                html = "<p>System will make a prediction for User: " + str(user_name) + "</p>"
                html = html + "<p>||<a href=" + url_for('predict') + ">Make Prediction||</a>"
                html = html + "<a href=" + url_for('updatemodel') + ">Update Model</a>||</p>"
                return html

        return render_template('GetUserName.html', form=form)

    @app.route("/predict")
    def predict():
        global user_name
        html = f"<h3>{user_name}</h3>"
        html = html + "<p>" + make_prediction(user_name=user_name) + "</p>"
        html = html + "<p>||<a href=" + url_for('home') + ">Input User Name</a>||"
        html = html + "<a href=" + url_for('updatemodel') + ">Update Model</a>||</p>"
        return html

    @app.route("/getuserdata", methods=['GET', 'POST'])
    def getuserdata():
        form = GetUserData()
        if request.method == 'POST':
            if form.user_data_url.data and form.user_data_encoding.data and form.validate_on_submit():
                data_url = form.user_data_url.data
                data_encoding = form.user_data_encoding.data
                try:
                    global user_data
                    user_data = pd.read_csv(data_url, encoding=data_encoding)
                except Exception as error:
                    return str(error)
                cols = list(user_data.columns)
                for col in INPUT_COLS:
                    if col in cols:
                        continue
                    else:
                        html = "<p>Data Validation ERROR</p>"
                        html = html + "<p>" + ",".join(INPUT_COLS) + " must be present</p"
                        return html
                html = "<h2>Fist 5 rows of input data: </h2>"
                html = html + user_data.head().to_html()
                html = html + "<p>||<a href=" + url_for('updatemodel') + ">Update Model</a>||</p>"
                return html
        return render_template('GetUserData.html', form=form)

    @app.route("/updatemodel", methods=['GET', 'POST'])
    def updatemodel():
        global user_data
        if user_data is not None:
            res = update_model(user_data=user_data)
            html = f"<p>Status:{res.get('status')}</p>"
        else:
            html = "<p>No user Data</p>"
        html = html + "<p><a href=" + url_for('getuserdata') + ">Input User Data</a>"
        html = html + "||<a href=" + url_for('home') + ">Input User Name</a>||</p>"
        return html
    return app


if __name__ == '__main__':
    create_app().run()
