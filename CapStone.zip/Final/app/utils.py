import numpy as np
import pandas as pd
from spacy.cli import download

try:
    import en_core_web_sm
except Exception:
    download("en_core_web_sm")
    import en_core_web_sm

nlp = en_core_web_sm.load()

from string import punctuation
from sklearn.metrics.pairwise import pairwise_distances

from constants import COLS_OF_INTEREST, INPUT_COLS, OUTPUT_COLS, SENTIMENTS, PICKLE_FILE_PATH, NUM_PRODUCTS, \
    PICKLE_FILE_PATH_SENTIMENT


def filter_data(input_df: pd.DataFrame,
                cols_of_Interest=COLS_OF_INTEREST):
    if isinstance(input_df, pd.DataFrame):
        cols = input_df.columns
        for col in cols_of_Interest:
            if col not in cols:
                error = "Required columns are not present in the input"
                raise Exception(f"ERORR:{error}")
        return pd.DataFrame(input_df[cols_of_Interest])
    else:
        error = f"Input is a {type(input_df)}, pandas.core.frame.DataFrame Expected"
        raise ValueError(f"ERORR:{error}")


def normalize_text(input_text: str = None, strip_str: str = None, drop_sp_chars: bool = True,
                   drop_leading_sp_char: bool = True):
    if not isinstance(input_text, str):
        return input_text
    ret = input_text
    if strip_str:
        ret = ret.replace(strip_str, "")
    ret = ret.lower()
    sp_chars = set(punctuation)
    if drop_sp_chars:
        for char in sp_chars:
            ret = ret.replace(char, "")
    if drop_leading_sp_char and len(ret) > 1:
        if ret[0] in sp_chars:
            ret = ret[1:]
    return ret


def normalize_df(input_df: pd.DataFrame, keep_sp_chars_cols=None):
    if keep_sp_chars_cols is None:
        keep_sp_chars_cols = ['id']
    if isinstance(input_df, pd.DataFrame):
        ret = input_df
        for col in list(ret.columns):
            if col not in keep_sp_chars_cols:
                ret[col] = ret[col].apply(normalize_text)
            else:
                ret[col] = ret[col].apply(normalize_text, drop_sp_chars=False)
        ret.drop_duplicates(inplace=True)
        return ret


def prep_model_data(input_df: pd.DataFrame,
                    input_cols=INPUT_COLS,
                    output_cols=OUTPUT_COLS):
    ret = pd.DataFrame(columns=output_cols)
    if isinstance(input_df, pd.DataFrame):
        ret[output_cols[0]] = input_df[input_cols[0]]
        ret[output_cols[1]] = input_df[input_cols[1]]
        ret[output_cols[2]] = input_df[input_cols[2]]
        ret[output_cols[3]] = input_df[input_cols[3]].map(SENTIMENTS)
        ret[output_cols[4]] = input_df[input_cols[4]]
        ret[output_cols[5]] = input_df[input_cols[5]] + " " + input_df[input_cols[6]]

    ret.drop(ret[ret[output_cols[5]].isna()].index, inplace=True)
    ret.reset_index(inplace=True, drop=True)
    ret[output_cols[2]].fillna('Unknown', inplace=True)
    return ret


def pickle_model(user_data: pd.DataFrame, file_path: str = PICKLE_FILE_PATH,
                 file_path_sentiment: str = PICKLE_FILE_PATH_SENTIMENT) -> dict:
    try:
        ratings_filtered = filter_data(user_data)
        ratings_filtered = normalize_df(ratings_filtered)
        model_data = prep_model_data(input_df=ratings_filtered)
        mean_user_rating = pd.DataFrame(model_data.groupby(['username'])['reviews_rating'].mean())
        model_data['mean_user_rating'] = model_data['username'].apply(
            lambda x: mean_user_rating.loc[x]['reviews_rating'])
        model_data['rating'] = model_data['reviews_rating'] - model_data['mean_user_rating']
        model_data_reduced = pd.DataFrame(model_data[['product_name', 'username', 'rating']])
        df_pivot = model_data_reduced.pivot_table(index="product_name", columns="username", values="rating").fillna(0)
        dummy_df = model_data_reduced.copy()
        dummy_df['rating'] = dummy_df['rating'].apply(lambda x: 0 if x >= 1 else 1)
        dummy_df = dummy_df.pivot_table(index="product_name", columns="username", values="rating").fillna(1)
        item_correlation = 1 - pairwise_distances(df_pivot, metric='cosine')
        item_correlation[np.isnan(item_correlation)] = 0
        item_correlation[item_correlation < 0] = 0
        item_predicted_ratings = np.dot(item_correlation, df_pivot)
        item_final_rating = np.multiply(item_predicted_ratings, dummy_df)
        item_final_rating.to_pickle(file_path)
        sentiment_data = pd.DataFrame(model_data[['product_name', 'user_sentiment']])
        sentiment_data_count = sentiment_data.groupby(by='product_name').count()
        sentiment_data = sentiment_data.groupby(by='product_name').sum()
        sentiment_data = (sentiment_data/sentiment_data_count)*100
        sentiment_data = sentiment_data.sort_values(by='user_sentiment', ascending=False)
        sentiment_data.to_pickle(file_path_sentiment)
        return {'status': 'OK',
                'file_path': file_path}
    except Exception as error:
        return {'status': 'Error',
                'Error': str(error)}


def recommend_products(username: str = None, num_product: int = 20,
                       file_path: str = PICKLE_FILE_PATH, file_path_sentiment: str = PICKLE_FILE_PATH_SENTIMENT):
    if not username:
        return "Error:No username passed"
    item_final_rating = pd.read_pickle(file_path)
    sentiment_data = pd.read_pickle(file_path_sentiment)
    try:
        products = item_final_rating.T.loc[username].sort_values(ascending=False)[0:num_product]
        products = list(products.index)
    except KeyError as error:
        return "User " + str(error) + " Not present in the data"
    ret = pd.DataFrame(sentiment_data.loc[products])
    ret = ret.sort_values(by='user_sentiment', ascending=False)
    ret = ret.head(NUM_PRODUCTS)
    return list(ret.index)
