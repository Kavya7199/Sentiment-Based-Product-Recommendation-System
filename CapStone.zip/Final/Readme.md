# Build the app Image
````
> cd <localtion>/app
> docker build . -t recomender:v1
````

# Start the app
````
> docker images                   
REPOSITORY   TAG       IMAGE ID       CREATED          SIZE
recomender   v1        7c66f34bde96   10 minutes ago   1.48GB
python       3.10      45e2736b39fe   2 days ago       917MB

>  docker run -p 5000:5000 7c66f34bde96
````
**IMAGE ID will differ system to system**

# Access the app

- Open the browser (Chrome, firefox etc.) on the system
- Navigate to http://localhost:5000